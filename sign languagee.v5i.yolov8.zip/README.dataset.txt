# sign languagee > 2024-12-24 11:42pm
https://universe.roboflow.com/gehiv/sign-languagee-sb59j

Provided by a Roboflow user
License: CC BY 4.0

